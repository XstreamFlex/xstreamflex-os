/**
 * XIMG Integration SDK & Widget (v1.0.0)
 * Seamless image upload & WebP optimization for XSITE, EZsite, and external apps.
 */
(function (window) {
    'use strict';

    const XImg = {
        baseUrl: (function() {
            const scripts = document.getElementsByTagName('script');
            for (let s of scripts) {
                if (s.src && s.src.includes('ximg-widget.js')) {
                    return s.src.replace(/\/ximg-widget\.js.*$/, '');
                }
            }
            return window.location.origin;
        })(),

        apiKey: '',

        init: function (options) {
            options = options || {};
            if (options.baseUrl) this.baseUrl = options.baseUrl.replace(/\/$/, '');
            if (options.apiKey) this.apiKey = options.apiKey;
            else {
                // Auto-detect XSITE key
                this.apiKey = localStorage.getItem('xsites_key') || 
                              localStorage.getItem('xsites_license_key') || 
                              localStorage.getItem('xsites_active_key') || '';
            }
            return this;
        },

        upload: async function (source, options) {
            options = options || {};
            const key = options.apiKey || this.apiKey || this.detectKey();
            const endpoint = (options.baseUrl || this.baseUrl) + '/api/upload.php';

            let body = null;
            let headers = {};

            if (key) {
                headers['X-API-Key'] = key;
            }

            if (source instanceof File || source instanceof Blob) {
                const formData = new FormData();
                formData.append('file', source, source.name || 'image.png');
                if (key) formData.append('api_key', key);
                body = formData;
            } else if (typeof source === 'string') {
                headers['Content-Type'] = 'application/json';
                if (source.startsWith('data:image/')) {
                    body = JSON.stringify({ base64: source, api_key: key });
                } else {
                    body = JSON.stringify({ url: source, api_key: key });
                }
            } else {
                throw new Error('Invalid upload source provided to XImg.upload()');
            }

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: headers,
                body: body
            });

            const data = await response.json();
            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Failed to upload image to XIMG.');
            }

            return data;
        },

        detectKey: function () {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('key') || 
                   urlParams.get('licenseKey') || 
                   localStorage.getItem('xsites_key') || 
                   localStorage.getItem('xsites_license_key') || '';
        },

        attachToInput: function (targetInput, options) {
            options = options || {};
            const inputEl = typeof targetInput === 'string' ? document.querySelector(targetInput) : targetInput;
            if (!inputEl) return;

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'ximg-upload-btn px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg shadow transition inline-flex items-center gap-1.5 ml-2 cursor-pointer';
            btn.innerHTML = '<span>⚡</span> Upload to XIMG';

            const fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.accept = 'image/*';
            fileInput.style.display = 'none';

            btn.addEventListener('click', () => fileInput.click());

            fileInput.addEventListener('change', async () => {
                if (!fileInput.files.length) return;
                const file = fileInput.files[0];
                btn.disabled = true;
                btn.innerHTML = '<span>⏳</span> Optimizing...';

                try {
                    const result = await XImg.upload(file, options);
                    inputEl.value = result.direct_url;
                    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
                    inputEl.dispatchEvent(new Event('change', { bubbles: true }));
                    btn.innerHTML = '<span>✅</span> Uploaded!';
                    setTimeout(() => { btn.innerHTML = '<span>⚡</span> Upload to XIMG'; btn.disabled = false; }, 2000);
                    if (typeof options.onSuccess === 'function') options.onSuccess(result);
                } catch (err) {
                    alert('XIMG Upload Failed: ' + err.message);
                    btn.innerHTML = '<span>❌</span> Failed';
                    setTimeout(() => { btn.innerHTML = '<span>⚡</span> Upload to XIMG'; btn.disabled = false; }, 2500);
                }
            });

            inputEl.parentNode.insertBefore(btn, inputEl.nextSibling);
            document.body.appendChild(fileInput);
        },

        openPicker: function (options) {
            options = options || {};
            const existingModal = document.getElementById('ximgPickerModal');
            if (existingModal) existingModal.remove();

            const modal = document.createElement('div');
            modal.id = 'ximgPickerModal';
            modal.style.cssText = 'position:fixed;inset:0;background:rgba(9,10,15,0.85);backdrop-filter:blur(8px);z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px;font-family:"Plus Jakarta Sans",sans-serif;';
            
            modal.innerHTML = `
                <div style="background:#11131e;border:1px solid #1e293b;border-radius:16px;max-width:540px;width:100%;padding:24px;color:#fff;box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);">
                    <div style="display:flex;align-items:center;justify-content:between;margin-bottom:16px;">
                        <h3 style="font-weight:800;font-size:18px;margin:0;">⚡ XIMG Web-Optimized Media Picker</h3>
                        <button id="ximgCloseBtn" style="background:none;border:none;color:#94a3b8;font-size:20px;cursor:pointer;">✕</button>
                    </div>
                    
                    <div id="ximgDropZone" style="border:2px dashed #34d399;border-radius:12px;padding:32px 16px;text-align:center;background:rgba(52,211,153,0.03);cursor:pointer;margin-bottom:16px;">
                        <div style="font-size:36px;margin-bottom:8px;">🖼️</div>
                        <p style="font-weight:700;margin:0 0 4px 0;">Drop Image Here or Click to Browse</p>
                        <p style="font-size:12px;color:#94a3b8;margin:0;">Automatically converts to WebP & optimizes size</p>
                        <input type="file" id="ximgFileInput" accept="image/*" style="display:none;">
                    </div>

                    <div id="ximgPickerStatus" style="display:none;font-size:13px;font-family:monospace;color:#34d399;text-align:center;padding:8px;">
                        Optimizing image...
                    </div>
                </div>
            `;

            document.body.appendChild(modal);

            const fileInput = modal.querySelector('#ximgFileInput');
            const dropZone = modal.querySelector('#ximgDropZone');
            const closeBtn = modal.querySelector('#ximgCloseBtn');
            const status = modal.querySelector('#ximgPickerStatus');

            closeBtn.onclick = () => modal.remove();
            dropZone.onclick = () => fileInput.click();

            const handleFile = async (file) => {
                status.style.display = 'block';
                status.innerText = '⚡ Converting to WebP and optimizing...';
                try {
                    const result = await XImg.upload(file, options);
                    modal.remove();
                    if (typeof options.onSelect === 'function') {
                        options.onSelect(result);
                    }
                } catch (err) {
                    status.style.color = '#ef4444';
                    status.innerText = '❌ Error: ' + err.message;
                }
            };

            fileInput.onchange = () => {
                if (fileInput.files.length) handleFile(fileInput.files[0]);
            };

            dropZone.ondragover = (e) => { e.preventDefault(); dropZone.style.borderColor = '#22c55e'; };
            dropZone.ondragleave = () => { dropZone.style.borderColor = '#34d399'; };
            dropZone.ondrop = (e) => {
                e.preventDefault();
                if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
            };
        }
    };

    XImg.init();
    window.XImg = XImg;
})(window);
